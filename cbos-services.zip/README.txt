CBOS Services (Bridge + Scraper)
=================================

Este pacote adiciona dois serviços ao repositório:
- cbos-scraper: Playwright "Search Like Human" (endpoint POST /search-human, GET /healthz)
- cbos-bridge : Proxy normalizador (endpoint POST /api/search-human, GET /healthz)

Como usar (resumo):
1) Faça upload destas pastas para a raiz do repositório GitHub `andrevieira-spec/ocitocinante`.
2) No Google Cloud Run, crie dois serviços com deploy contínuo via GitHub:
   - cbos-scraper (diretório: cbos-scraper, Dockerfile: cbos-scraper/Dockerfile)
   - cbos-bridge  (diretório: cbos-bridge,  Dockerfile: cbos-bridge/Dockerfile)
   Ambos com Porta 8080 e Acesso público habilitado.
3) Após o deploy do scraper, copie a URL gerada e configure no serviço do bridge como variável:
   - CBOS_SCRAPER_URL = https://cbos-scraper-XXXX.southamerica-east1.run.app
4) No frontend (Vercel) configure:
   - NEXT_PUBLIC_BRIDGE_URL = https://cbos-bridge-XXXX.southamerica-east1.run.app
5) Teste:
   - GET  <bridge>/healthz
   - POST <bridge>/api/search-human  body: {"query":"passagem sao paulo lisboa 2026","numPages":2}

Observações:
- Node 20 em ambos os serviços.
- Scraper usa Playwright (imagem oficial mcr.microsoft.com/playwright:v1.47.2-jammy).
- Bridge inclui CORS para chamadas do Vercel.
