import express from "express";
import fetch from "node-fetch";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

const SCRAPER_URL = process.env.CBOS_SCRAPER_URL;

app.post("/api/search-human", async (req, res) => {
  if (!SCRAPER_URL) return res.status(500).json({ ok:false, error:"CBOS_SCRAPER_URL não configurada" });
  try {
    const r = await fetch(`${SCRAPER_URL}/search-human`, {
      method: "POST",
      headers: { "content-type":"application/json" },
      body: JSON.stringify(req.body || {})
    });
    const json = await r.json();
    res.status(r.ok ? 200 : r.status).json(json);
  } catch (e) {
    res.status(502).json({ ok:false, error:e.message });
  }
});

app.get("/healthz", (_,res)=>res.json({ ok:true, service:"cbos-bridge" }));

const PORT = process.env.PORT || 8080;
app.listen(PORT, ()=>console.log(`[bridge] listening :${PORT}`));
