import express from "express";
import { chromium, devices } from "playwright";
import UAParser from "ua-parser-js";

const app = express();
app.use(express.json({ limit: "1mb" }));

// Healthcheck
app.get("/healthz", (req, res) => res.json({ ok: true, service: "cbos-scraper", mode: "search-like-human" }));

// Utils
const wait = ms => new Promise(r => setTimeout(r, ms));
const jitter = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

const UAS = [
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15",
  devices["iPhone 13 Pro"].userAgent
];

const VIEWPORTS = [
  { width: 1366, height: 768 },
  { width: 1440, height: 900 },
  { width: 1920, height: 1080 },
  devices["iPhone 13 Pro"].viewport
];

async function humanType(page, selector, text) {
  const el = await page.waitForSelector(selector, { timeout: 15000 });
  await el.click({ delay: jitter(50, 150) });
  for (const ch of text) {
    await page.keyboard.type(ch, { delay: jitter(40, 120) });
    if (Math.random() < 0.08) await wait(jitter(120, 300));
  }
}

async function humanScroll(page) {
  const total = jitter(2, 4);
  for (let i = 0; i < total; i++) {
    await page.mouse.wheel(0, jitter(600, 1200));
    await wait(jitter(300, 900));
  }
}

function parseResults() {
  return Array.from(document.querySelectorAll("div.g")).map((g, i) => {
    const a = g.querySelector("a");
    const h3 = g.querySelector("h3");
    const snippet = g.querySelector("div[data-sncf], span, div.VwiC3b")?.innerText || "";
    return a && h3 ? { rank: i + 1, title: h3.innerText, url: a.href, snippet } : null;
  }).filter(Boolean);
}

app.post("/search-human", async (req, res) => {
  const t0 = Date.now();
  const {
    query,
    numPages = 1,
    locale = "pt-BR",
    country = "br",
    safe = "off",
    mobile = false
  } = req.body || {};

  if (!query || typeof query !== "string") return res.status(400).json({ ok: false, error: "query obrigatória" });

  const ua = mobile ? UAS[2] : UAS[0];
  const viewport = mobile ? VIEWPORTS[3] : VIEWPORTS[Math.floor(Math.random()*3)];

  const launchArgs = ["--no-sandbox", "--disable-dev-shm-usage"];
  const browser = await chromium.launch({ headless: true, args: launchArgs });

  let page;
  const anti = { userAgent: ua, viewport, actions: [] };
  const results = [];
  try {
    const ctx = await browser.newContext({
      userAgent: ua,
      viewport,
      locale,
      geolocation: { latitude: -23.5505, longitude: -46.6333 },
      permissions: ["geolocation"]
    });
    page = await ctx.newPage();
    await page.mouse.move(100, 100, { steps: 10 });

    const q = encodeURIComponent(query);
    const url = `https://www.google.com/search?q=${q}&hl=${locale}&gl=${country}&safe=${safe}`;
    await page.goto(url, { waitUntil: "domcontentloaded", timeout: 45000 });
    anti.actions.push("goto");

    // Aceitar cookies se aparecer
    const acceptSelectors = [
      'button[aria-label="Aceitar tudo"]',
      '#L2AGLb',
      'button:has-text("Aceitar")'
    ];
    for (const sel of acceptSelectors) {
      const btn = await page.$(sel);
      if (btn) { await btn.click().catch(()=>{}); anti.actions.push("cookies.accept"); break; }
    }

    const searchBoxSel = 'textarea[name="q"], input[name="q"]';
    await humanType(page, searchBoxSel, " ");
    await page.keyboard.press("Backspace");

    await humanScroll(page);

    let batch = await page.evaluate(parseResults);
    results.push(...batch);

    for (let p = 2; p <= Math.min(5, numPages); p++) {
      const more = await page.$('a[aria-label="Mais resultados"], a#pnnext');
      if (!more) break;
      await more.scrollIntoViewIfNeeded();
      await wait(jitter(300, 800));
      await more.click();
      anti.actions.push("next_page_click");
      await page.waitForLoadState("domcontentloaded", { timeout: 30000 });
      await wait(jitter(500, 1200));
      await humanScroll(page);
      batch = await page.evaluate(parseResults);
      results.push(...batch);
    }

    const elapsedMs = Date.now() - t0;
    res.json({
      ok: true,
      engine: "google",
      mode: "search-like-human",
      query,
      count: results.length,
      results,
      timing: { elapsedMs },
      anti_bot: anti
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  } finally {
    if (page) await page.context().close().catch(()=>{});
    await browser.close().catch(()=>{});
  }
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`[scraper] listening :${PORT}`));
