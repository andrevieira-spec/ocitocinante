COMO USAR ESTE PACOTE (UPLOAD RÁPIDO):

1) No GitHub (repositório andrevieira-spec/ocitocinante):
   - Clique em "Add file" -> "Upload files"
   - Arraste TODO o conteúdo desta pasta para a raiz do repositório
     (pastas .github e scripts, e arquivos .nvmrc, vercel.json, .env.example).
   - Confirme o Commit.

2) Ajuste o package.json manualmente (se necessário):
   - Abra o arquivo package.json no GitHub Web Editor e
     adicione/ajuste os scripts conforme o arquivo package.scripts.snippet.json.
   - Se preferir substituir completamente, use o arquivo opcional package.example.json.

3) GitHub Actions -> Aba "Actions" -> Rode o workflow "Build & Release ZIP"
   - Clique em "Run workflow", informe a versão (ex: v1.0.0) e execute.
   - Depois vá em "Releases" e baixe o ZIP gerado.

4) Vercel:
   - No Dashboard do Vercel, configure as variáveis de ambiente listadas em .env.example
   - Faça o Deploy/Redeploy. O link final aparece ao concluir.
