# Ocitocinante — Base pronta (Node 20 / Next 14)

## Como usar
1. **Apague tudo** do seu repo atual e **envie o conteúdo deste ZIP** para a raiz do repositório.
2. No GitHub, confirme o **Commit**.
3. Na Vercel, configure as **Environment Variables** (veja `.env.example`) e faça **Deploy**.
4. Healthcheck disponível em `/api/health`.

## Scripts úteis
- `npm run dev` — desenvolvimento local
- `npm run build` — build de produção (falha se faltar env crítica)
- `npm start` — serve produção
- `npm run zip:release` — gera ZIP (dist/*.zip)

## GitHub Actions
- **Build & Release ZIP** (manual por versão ou por tag `v*.*.*`).
