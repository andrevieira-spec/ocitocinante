import type { NextApiRequest, NextApiResponse } from 'next';

export default function handler(_req: NextApiRequest, res: NextApiResponse) {
  res.status(200).json({
    success: true,
    mode: 'quick',
    message: 'Análise rápida concluída',
    timestamp: new Date().toISOString(),
    api_health: {
      x_api: { healthy: true, error: null },
      instagram_api: { healthy: true, error: null },
      google_search: { healthy: true, error: null }
    }
  });
}
