import Head from 'next/head';

export default function Home() {
  return (
    <>
      <Head>
        <title>Ocitocinante</title>
      </Head>
      <main style={{padding:'40px', fontFamily:'system-ui, -apple-system, Segoe UI, Roboto'}}>
        <h1 style={{marginBottom:8}}>Ocitocinante</h1>
        <p style={{opacity:0.8}}>Base pronta em Next.js (Node 20).*</p>
        <ul>
          <li>Variáveis: configure em Vercel (veja .env.example)</li>
          <li>Healthcheck: <code>/api/health</code></li>
        </ul>
        <hr />
        <p style={{fontSize:12, opacity:0.7}}>* Substitua/adicione suas páginas e componentes aqui.</p>
      </main>
    </>
  );
}
