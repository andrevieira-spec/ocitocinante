const required = ['SUPABASE_URL','SUPABASE_ANON_KEY'];
const missing = required.filter(k => !process.env[k]);
if (missing.length) {
  console.error('Faltam variáveis de ambiente:', missing.join(', '));
  process.exit(1);
}
