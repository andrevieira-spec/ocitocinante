#!/usr/bin/env bash
set -euo pipefail

APP_NAME="ocitocinante"
VERSION_TAG="${1:-v$(date +%Y%m%d-%H%M%S)}"
OUTDIR="dist"
ZIPNAME="${APP_NAME}-${VERSION_TAG}.zip"

echo "==> Limpando artefatos..."
rm -rf "${OUTDIR}"
mkdir -p "${OUTDIR}"

echo "==> Instalando deps limpas..."
rm -rf node_modules
npm ci

echo "==> Build..."
npm run build

echo "==> Preparando pacote..."
INCLUDE=(
  ".next"
  "public"
  "package.json"
  "package-lock.json"
  "next.config.mjs"
  "vercel.json"
  ".nvmrc"
  ".env.example"
)
TMPDIR="$(mktemp -d)"
for p in "${INCLUDE[@]}"; do
  if [ -e "$p" ]; then
    mkdir -p "$(dirname "${TMPDIR}/$p")"
    cp -R "$p" "${TMPDIR}/$p"
  fi
done

echo "==> Gerando ZIP ${ZIPNAME}..."
( cd "${TMPDIR}" && zip -r "../${OUTDIR}/${ZIPNAME}" . >/dev/null )
rm -rf "${TMPDIR}"

echo "==> Pronto: ${OUTDIR}/${ZIPNAME}"
