# SLH (Search Like Human) — Integração para X e Instagram

## Variáveis (Vercel → Settings → Environment Variables)
- `SLH_ENABLED=true`
- `USE_X_API=false`
- `USE_INSTAGRAM_API=false`
- `SLH_BASE_URL=https://cbos-scraper-XXXXXXXX-uc.a.run.app`  ← ajuste para o seu URL do Cloud Run
- `SLH_TOKEN=seu_token_compartilhado`  ← defina o mesmo no serviço scraper

## Endpoints esperados no seu scraper (Cloud Run)
- `GET /slh/x?q={query}&lang=pt&max=10`
- `GET /slh/instagram?q={query}&lang=pt&max=10`
- (opcional) `GET /slh/google`, `GET /slh/youtube`, etc.

**Autorização:** cabeçalho `Authorization: Bearer {SLH_TOKEN}`

## Rotas internas prontas neste app
- `GET /api/slh/x?q=...`
- `GET /api/slh/instagram?q=...`

Essas rotas fazem proxy para o seu scraper usando `SLH_BASE_URL` e `SLH_TOKEN`.

## Testes
```bash
# X (Twitter) via proxy local do app
curl 'https://SEU_DOMINIO.vercel.app/api/slh/x?q=ocitocina%20viagens&lang=pt&max=5'

# Instagram via proxy local do app
curl 'https://SEU_DOMINIO.vercel.app/api/slh/instagram?q=ocitocina%20viagens&lang=pt&max=5'
```
