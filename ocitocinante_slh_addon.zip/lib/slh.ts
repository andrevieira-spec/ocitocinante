type Provider = 'x' | 'instagram' | 'google' | 'youtube';

interface SlhParams {
  provider: Provider;
  q: string;
  lang?: string;
  max?: number;
}

export async function slhFetch<T = unknown>({ provider, q, lang, max }: SlhParams): Promise<T> {
  if (process.env.SLH_ENABLED !== 'true') {
    throw new Error('SLH_DISABLED: Set SLH_ENABLED=true in environment.');
  }
  const base = process.env.SLH_BASE_URL;
  const token = process.env.SLH_TOKEN;
  if (!base || !token) {
    throw new Error('SLH_MISCONFIG: SLH_BASE_URL and SLH_TOKEN are required.');
  }

  const url = new URL(`/slh/${provider}`, base);
  url.searchParams.set('q', q);
  if (lang) url.searchParams.set('lang', lang);
  if (max) url.searchParams.set('max', String(max));

  const res = await fetch(url.toString(), {
    headers: { 'Authorization': `Bearer ${token}` },
    next: { revalidate: 0 }
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`SLH_HTTP_${res.status}: ${text}`);
  }
  return res.json() as Promise<T>;
}
