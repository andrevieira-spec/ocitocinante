import type { NextApiRequest, NextApiResponse } from 'next';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  try {
    const { provider } = req.query as { provider: 'x'|'instagram'|'google'|'youtube' };
    const q = (req.query.q || '').toString();
    const lang = (req.query.lang || '').toString() || undefined;
    const max = req.query.max ? Number(req.query.max) : undefined;

    if (!provider || !q) {
      res.status(400).json({ error: 'Missing provider or q' });
      return;
    }

    if (process.env.SLH_ENABLED !== 'true') {
      res.status(503).json({ error: 'SLH_DISABLED' });
      return;
    }

    const base = process.env.SLH_BASE_URL;
    const token = process.env.SLH_TOKEN;
    if (!base || !token) {
      res.status(500).json({ error: 'SLH_MISCONFIG', need: ['SLH_BASE_URL','SLH_TOKEN'] });
      return;
    }

    const target = new URL(`/slh/${provider}`, base);
    target.searchParams.set('q', q);
    if (lang) target.searchParams.set('lang', lang);
    if (typeof max === 'number') target.searchParams.set('max', String(max));

    const upstream = await fetch(target.toString(), {
      headers: { 'Authorization': `Bearer ${token}` },
    });

    const text = await upstream.text();
    res.status(upstream.status);
    try {
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      res.send(JSON.parse(text));
    } catch {
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      res.send(text);
    }
  } catch (err: any) {
    res.status(500).json({ error: 'SLH_PROXY_ERROR', message: err?.message || String(err) });
  }
}
